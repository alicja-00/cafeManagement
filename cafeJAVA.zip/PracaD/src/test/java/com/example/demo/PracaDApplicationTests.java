package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.customer.Customer;
import com.example.demo.customer.CustomerRepository;

@SpringBootTest
class PracaDApplicationTests {

	@Autowired
	CustomerRepository repository;
	
	
	@Test
	public void contextLoads() {
	}
	
	@Test
	public void testCustomerCreate() {
	 Customer customer = new Customer();
	 customer.setName("Julia Roberts");
	 customer.setEmail("julie@onet.pl");
	 customer.setAddress("Sloniowa 122/33");
	 customer.setPhone("887654322");
	 repository.save(customer);
	
	}
	@Test
	public void testCustomerById() {
	if (repository.existsById(5)) {
	Customer customer = repository.findById(5).get();
	assertNotNull(customer);
	assertEquals("Maria Antonina", customer.getName());
	System.out.println("Maria Antonina" + customer.getEmail());
	}
	}
	@Test
	public void testUpdateCustomer() {
	if (repository.existsById(1)) {
	Customer customer = repository.findById(1).get();
	customer.setEmail("new@email.com");
	repository.save(customer);
	}
	}
	@Test
	public void testDeleteCustomer() {
	if (repository.existsById(2)) {
	System.out.println("Deleting a customer");
	repository.deleteById(2);
	}
	}
	@Test
	public void testCount() {
	 System.out.println("Number of records:" + repository.count());
	}

}
