package com.example.demo.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.category.Category;


import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import javax.servlet.http.HttpServletResponse;

import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
 
@Controller
public class CartController {
	
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private CartServices service;
	@Autowired
	private ProductRepository prodRepo;
	

	
	@GetMapping("/cart/new")
	public String showCreateNewCartForm (Model model) {
		List<Product> listProduct = prodRepo.findAll();
		model.addAttribute("listProduct", listProduct);
		model.addAttribute("cart", new Cart());
		return "cart_form";
	}
	
	@PostMapping("/cart/save")
	public String saveCart(Cart cart) {
		cartRepo.save(cart);
		return "redirect:/cart";
	}
	@GetMapping("/cart")
	public String listCart (Model model) {
		List<Cart> listCart = cartRepo.findAll();
		model.addAttribute("listCart", listCart);
		return  "cart";
	}

	@GetMapping("/cart/edit/{id}")
	public String showEditCartForm(@PathVariable("id") Integer id, Model model) {
		List<Product> listProduct = prodRepo.findAll();
		Cart cart= cartRepo.findById(id).get();
	    model.addAttribute("listProduct", listProduct);
	    model.addAttribute("cart", cart);
		return "cart_form";
	}
	@GetMapping("/cart/delete/{id}")
	public String deleteCart(@PathVariable("id") Integer id, Model model) {
		cartRepo.deleteById(id);
		return "redirect:/cart";
	}
	@GetMapping("/cart/export/pdf")
    public void exportToPDF(HttpServletResponse response) throws IOException, com.itextpdf.text.DocumentException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename= bill_" + currentDateTime +".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<Cart> listCart = service.listAll();
         
        CartPDFExporter exporter = new CartPDFExporter(listCart);
        exporter.export(response);
         
    }
}
