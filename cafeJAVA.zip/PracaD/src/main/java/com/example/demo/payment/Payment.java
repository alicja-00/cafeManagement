package com.example.demo.payment;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.example.demo.customer.Customer;
import com.example.demo.orders.Orders;
import com.example.demo.product.Cart;
import com.example.demo.product.Product;


@Entity
public class Payment {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@Enumerated(EnumType.STRING)
	private Status type;
	@Enumerated(EnumType.STRING)
	private Method pay;
	
	@OneToMany
	@JoinColumn(name = "payment_price")
	private List<Price> price = new ArrayList<>();
	
	public List<Price> getPrice() {
		return price;
	}
	public void setPrice(List<Price> price) {
		this.price = price;
	}
	public Orders getOrders() {
		return orders;
	}
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	@ManyToOne
	@JoinColumn(name= "order_id")
	private Orders orders;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	
	@Override
	public String toString() {
		return "Payment [id=" + id + ", type=" + type + ", pay=" + pay + "]";
	}
	public Status getType() {
		return type;
	}
	public void setType(Status type) {
		this.type = type;
	}
	public Method getPay() {
		return pay;
	}
	public Payment(Integer id, Float totalPrice) {
		this.id = id;
		
	}
	public void setPay(Method pay) {
		this.pay = pay;
	}
	
	public Payment() {
	}
	public Payment(Integer id) {
		this.id = id;
	}
	
	
}
