package com.example.demo.customer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.orders.Orders;
import com.example.demo.orders.OrdersRepository;


@Controller
public class CustomerController {
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private OrdersRepository ordersRepo;
	
	@GetMapping("/customer")
	public String listCustomer(Model model) {
		List<Customer> listCustomer = customerRepo.findAll();
		model.addAttribute("listCustomer", listCustomer);
		return "customer";
	}
	
	@GetMapping("/customer/new")
	public String showCustomerNewForm(Model model) {
		model.addAttribute("customer", new Customer());
		List<Orders> listOrders = ordersRepo.findAll();
		model.addAttribute("listOrders", listOrders);
		return "customer_form";
	}
	
	@PostMapping("/customer/save")
	public String saveCustomer(Customer customer) {
		customerRepo.save(customer);
		
		return "redirect:/";
	}
	@GetMapping("/customer/edit/{id}")
	public String showEditCustomerForm(@PathVariable("id") Integer id, Model model) {
		Customer customer = customerRepo.findById(id).get();
		model.addAttribute("customer", customer);
		model.addAttribute("customer", new Customer());
		return "customer_form";
	}
	
	@GetMapping("/customer/delete/{id}")
	public String deleteCustomer(@PathVariable("id") Integer id, Model model) {
		customerRepo.deleteById(id);
		List<Orders> listOrders = ordersRepo.findAll();
		model.addAttribute("listOrders", listOrders);
	return "redirect:/customer";
	
}


}
