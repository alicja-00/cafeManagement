package com.example.demo.payment;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.example.demo.product.Cart;

@Entity
public class Price {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private Float totalPrice;
	
	
	@OneToMany
	@JoinColumn(name = "price_id")
	private List<Cart> cart = new ArrayList<>();
	
	@ManyToOne
	@JoinColumn(name= "payment_price")
	private Payment payment;

	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	} 
	public Price() {
		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Float totalPrice) {
		this.totalPrice = totalPrice;
	}
	public List<Cart> getCart() {
		return cart;
	}
	@Override
	public String toString() {
		return "Price [totalPrice=" + totalPrice + "]";
	}
	public void setCart(List<Cart> cart) {
		this.cart = cart;
	}
}
