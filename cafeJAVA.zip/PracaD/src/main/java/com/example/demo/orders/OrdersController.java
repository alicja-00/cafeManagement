package com.example.demo.orders;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.customer.Customer;
import com.example.demo.customer.CustomerRepository;
import com.example.demo.employee.Employee;
import com.example.demo.employee.EmployeeRepository;
import com.example.demo.payment.Payment;
import com.example.demo.payment.PaymentRepository;
import com.example.demo.product.Cart;
import com.example.demo.product.CartRepository;
import com.example.demo.product.Product;
import com.example.demo.product.ProductRepository;

@Controller
public class OrdersController {
	@Autowired
	private OrdersRepository ordersRepo;
	@Autowired
	private ProductRepository productRepo;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private EmployeeRepository employeeRepo;
	
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private PaymentRepository payRepo;
	
	@GetMapping("/orders")
	public String listOrders(Model model) {
		List<Orders> listOrders = ordersRepo.findAll();
		model.addAttribute("listOrders", listOrders);
		return "orders";
	}
	@GetMapping("/orders/new")
	public String showOrdersNewForm(Model model) {
		model.addAttribute("orders", new Orders());
		List<Product> listProduct = productRepo.findAll();
		model.addAttribute("listProduct", listProduct);
		List<Customer> listCustomer = customerRepo.findAll();
		model.addAttribute("listCustomer", listCustomer);
		List<Employee> listEmployee = employeeRepo.findAll();
		model.addAttribute("listEmployee", listEmployee);
		List<Cart> listCart = cartRepo.findAll();
		model.addAttribute("listCart", listCart);
		model.addAttribute("supply", Supply.values());
		model.addAttribute("priority", Priority.values());
		return "orders_form";
	}
	@PostMapping("/orders/save")
	public String saveOrders(Orders orders) {
		
		    ordersRepo.save(orders);
			return "redirect:/";
		}
	}
	

