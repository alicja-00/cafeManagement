package com.example.demo.payment;

public enum Method {
	card ("card"),
	cash ("cash");
	
	private final String name;

	public String getName() {
		return name;
	}

	private Method(String name) {
		this.name = name;
	}
	
}
