package com.example.demo.product;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.example.demo.category.Category;
import com.example.demo.category.CategoryRepository;
import com.example.demo.orders.Orders;
import com.example.demo.orders.OrdersRepository;



@Controller
public class ProductController {
	@Autowired
	private ProductRepository repo;
	@Autowired
	private ProductServices service;
	@Autowired
	private CategoryRepository catRepo;
	
	
	@GetMapping("/product/new")
	public String showCreateNewProductForm (Model model) {
		List<Category> listCategory = catRepo.findAll();
		model.addAttribute("listCategory", listCategory);
		model.addAttribute("product", new Product());
		model.addAttribute("availability", Availability.values());
		return "product_form";
	}
	@PostMapping("/product/save")
	public String saveProduct(Product product) {
		repo.save(product);
		return "redirect:/";
	}
	@GetMapping("/product")
	public String listProduct (Model model) {
		List<Product> listProduct = repo.findAll();
		model.addAttribute("listProduct", listProduct);
		return "product";
	}
	@GetMapping("/product/edit/{id}")
	public String showEditProductForm(@PathVariable("id") Integer id, Model model) {
		List<Category> listCategory = catRepo.findAll();
		Product product= repo.findById(id).get();
	   model.addAttribute("listCategory", listCategory);
		model.addAttribute("availability", Availability.values());
	   model.addAttribute("product", product);
		return "product_form";
	}
	@GetMapping("/products/delete/{id}")
	public String deleteProduct(@PathVariable("id") Integer id, Model model) {
	repo.deleteById(id);
	return "redirect:/product";
	}
	
	 @GetMapping("/product/export")
	    public void exportToCSV(HttpServletResponse response) throws IOException {
	        response.setContentType("text/csv");
	        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
	        String currentDateTime = dateFormatter.format(new Date());
	         
	        String headerKey = "Content-Disposition";
	        String headerValue = "attachment; filename=menu_" + currentDateTime + ".csv";
	        response.setHeader(headerKey, headerValue);
	         
	        List<Product> listProduct = service.listAll();
	 
	        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
	        String[] csvHeader = {"Product ID", "NAME", "DESCRIPTION", "Price ZL"};
	        String[] nameMapping = {"id", "name", "description", "price"};
	         
	        csvWriter.writeHeader(csvHeader);
	         
	        for (Product product : listProduct) {
	            csvWriter.write(product, nameMapping);
	        }
	         
	        csvWriter.close();
	         
	    }
}