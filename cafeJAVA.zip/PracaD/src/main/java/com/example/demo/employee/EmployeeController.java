package com.example.demo.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.category.Category;
import com.example.demo.product.Product;


@Controller
public class EmployeeController {
	@Autowired
	private EmployeeRepository repo;
	
	@GetMapping("/employee")
	public String listEmployee(Model model) {
		List<Employee> listEmployee = repo.findAll();
		model.addAttribute("listEmployee", listEmployee);
		return "employee";
	}
	@GetMapping("/employee/new")
	public String showEmployeeNewForm(Model model) {
		model.addAttribute("employee", new Employee());
		return "employee_form";
	}
	@PostMapping("/employee/save")
	public String saveEmployee(Employee employee) {
		repo.save(employee);
		return "redirect:/";
	}
	@GetMapping("/employee/edit/{id}")
	public String showEditEmployeeForm(@PathVariable("id") Integer id, Model model) {
		
		Employee employee= repo.findById(id).get();
	   
	   model.addAttribute("employee", employee);
		return "product_form";
	}
	@GetMapping("/employee/delete/{id}")
	public String deleteEmployee(@PathVariable("id") Integer id, Model model) {
	repo.deleteById(id);
	return "redirect:/employee";
	}
}
