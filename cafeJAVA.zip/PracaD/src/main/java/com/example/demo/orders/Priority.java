package com.example.demo.orders;

public enum Priority {
	
	low ("LOW"),
	medium ("MEDIUM"),
	important ("IMPORTANT !");
	
	
	private final String name;

	public String getName() {
		return name;
	}

	private Priority (String name) {
		this.name = name;
	}

}
