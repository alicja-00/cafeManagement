package com.example.demo.product;

import java.util.List;
import java.awt.Color;
import java.io.IOException;
 
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class CartPDFExporter {
	
	private List<Cart> listCart;
	public CartPDFExporter(List<Cart> listCart) {
		this.listCart = listCart;
	}
	
	 
	 public void export(HttpServletResponse response) throws DocumentException, IOException {
	        Document document = new Document(PageSize.A7);
	        PdfWriter.getInstance(document, response.getOutputStream());
	         
	        document.open();
	        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
	        font.setSize(8);
	      
	        Paragraph p = new Paragraph("Cafe JAVA ul.Wroclawska22 50-400 Wroclaw", font);
	        p.setAlignment(Paragraph.ALIGN_CENTER);
	
	        document.add(p);

	     
	        for (Cart cart : listCart) {
	        Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD);
		    font2.setSize(7);
	     
	        Paragraph quantity = new Paragraph (cart.getProduct().getName() + "  " +cart.getQuantity().toString() + " x " +cart.getProduct().getPrice(), font2 );
	        quantity.setAlignment(Paragraph.LIST);
	        document.add(quantity);
	        
	        Paragraph sum = new Paragraph (cart.getPrice().getTotalPrice().toString() +" zl", font2);
	        sum.setAlignment(Paragraph.ALIGN_RIGHT);
	        document.add(sum);
	        
	        Paragraph pause = new Paragraph ("----------");
	        pause.setAlignment(Paragraph.ALIGN_RIGHT);
	        document.add(pause);
	        }
	       
	  
	        Paragraph b = new Paragraph("Thank you, see you next time!", font);
	        b.setAlignment(Paragraph.ALIGN_CENTER);
	     
	        document.add(b);
	        document.close();
	         
	    }

	
}
