package com.example.demo.payment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.category.Category;
import com.example.demo.category.CategoryRepository;
import com.example.demo.orders.Orders;
import com.example.demo.orders.OrdersRepository;
import com.example.demo.product.Cart;
import com.example.demo.product.CartRepository;

@Controller
public class PaymentController {
	@Autowired
	private PaymentRepository repo;
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private PriceRepository priceRepo;
	@Autowired
	private OrdersRepository oRepo;
	
	@GetMapping("/payment")
	public String listPayment(Model model) {
		List<Payment> listPayment = repo.findAll();
		model.addAttribute("listPayment", listPayment);
		return "payment";
	}
	
	@GetMapping("/payment/new")
	public String showPaymentNewForm(Model model) {
		List<Orders> listOrders = oRepo.findAll();
		model.addAttribute("listOrders", listOrders);
		List<Cart> listCart = cartRepo.findAll();
		model.addAttribute("listCart", listCart);
		List<Price> listPrice = priceRepo.findAll();
		model.addAttribute("listPrice", listPrice);
		model.addAttribute("payment", new Payment());
		model.addAttribute("status", Status.values());
		model.addAttribute("method", Method.values());
		
		return "payment_form";
	}
	@PostMapping("/payment/save")
	public String savePayment(Payment payment) {
		repo.save(payment);
		return "redirect:/payment";
	}
	
}
