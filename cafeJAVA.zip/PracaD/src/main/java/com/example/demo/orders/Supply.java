package com.example.demo.orders;

public enum Supply {
	here ("HERE"),
	takeAway ("TAKE AWAY");
	
	
	private final String name;

	private Supply (String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
