package com.example.demo.payment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.product.Cart;
import com.example.demo.product.CartRepository;

@Controller
public class PriceController {
	@Autowired
	private PriceRepository priceRepo;
	@Autowired
	private CartRepository cartRepo;
	
	
	
	@GetMapping("/price")
	public String listPrice(Model model) {
		List<Price> listPrice= priceRepo.findAll();
		model.addAttribute("listPrice", listPrice);
	
		return "price";
	}
	
	@GetMapping("/price/new")
	public String showPriceNewForm(Model model) {
		List<Cart> listCart = cartRepo.findAll();
		model.addAttribute("listCart", listCart);
		model.addAttribute("price", new Price());
		
		return "price_form";
	}
	@PostMapping("/price/save")
	public String savePrice(Price price) {
		priceRepo.save(price);
		return "redirect:/price";
	}
	
}
