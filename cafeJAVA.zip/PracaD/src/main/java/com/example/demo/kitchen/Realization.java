package com.example.demo.kitchen;

public enum Realization {
	
	inprogress ("work in progress"),
	completed("It is complete, done!");
	
	private final String name;

	public String getName() {
		return name;
	}

	private Realization (String name) {
		this.name = name;
	}
}
