package com.example.demo.product;

public enum Availability {
	
	available("available"),
	unavailable("unavailable");
	
	private final String name;

	public String getName() {
		return name;
	}

	private Availability (String name) {
		this.name = name;
	}
}
