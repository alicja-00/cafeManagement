package com.example.demo.kitchen;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.category.Category;
import com.example.demo.orders.Orders;
import com.example.demo.orders.OrdersRepository;
import com.example.demo.product.Cart;
import com.example.demo.product.Product;

@Controller
public class KitchenController {

	@Autowired
	private KitchenRepository repo;
	@Autowired
	private OrdersRepository ordersRepo;
	
	@GetMapping("/kitchen")
	public String listKitchen(Model model) {
		List<Kitchen> listKitchen = repo.findAll();
		model.addAttribute("listKitchen", listKitchen);
		return "kitchen";
	}
	@GetMapping("/kitchen/new")
	public String showCreateNewKitchenForm (Model model) {
		List <Orders> listOrders = ordersRepo.findAll();
		model.addAttribute("listOrders",listOrders);
		model.addAttribute("realization", Realization.values());
		model.addAttribute("kitchen", new Kitchen());
		return "kitchen_form";
	}
	
	@PostMapping("/kitchen/save")
	public String saveKitchen(Kitchen kitchen) {
		repo.save(kitchen);
		return "redirect:/kitchen";
	}
	@GetMapping("/kitchen/edit/{id}")
	public String showEditKitchenForm(@PathVariable("id") Integer id, Model model) {
		List<Orders> listOrders = ordersRepo.findAll();
		Kitchen kitchen = repo.findById(id).get();
		model.addAttribute("realization", Realization.values());
	   model.addAttribute("listOrders", listOrders);
	   model.addAttribute("kitchen", kitchen);
		return "kitchen_form";
	}
}
