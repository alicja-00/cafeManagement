package com.example.demo.product;

import java.util.List;

import javax.transaction.Transactional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
@Service
@Transactional
public class CartServices {
	
	 @Autowired
	 private CartRepository repo;
	     
	 public List<Cart> listAll() { 
	 return repo.findAll();
	    }
	 
}

