package com.example.demo.orders;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.example.demo.category.Category;
import com.example.demo.customer.Customer;
import com.example.demo.employee.Employee;
import com.example.demo.kitchen.Kitchen;
import com.example.demo.payment.Payment;
import com.example.demo.product.Cart;
import com.example.demo.product.Product;


@Entity
public class Orders {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private String description;
	private String createDate;
	private String deliveryTime;
	@Enumerated(EnumType.STRING)
	private Supply type;
	@Enumerated(EnumType.STRING)
	private Priority prio;
	
	@OneToMany
	@JoinColumn(name = "kitchen_orders")
	private List<Kitchen> kitchen = new ArrayList<>();

	@OneToMany
	@JoinColumn(name = "payment_id")
	private List<Payment> payment = new ArrayList<>();

	@ManyToOne
	@JoinColumn(name= "customer_id")
	private Customer customer;
	
	@ManyToMany
	@JoinTable(name = "order_cart")
	private Set<Cart> cart = new HashSet<>();
	
	@ManyToOne
	@JoinColumn(name= "employee_id")
	private Employee employee;
	
	@ManyToMany
	@JoinTable(name = "order_product")
	private Set<Product> product = new HashSet<>();
	
	public List<Payment> getPayment() {
		return payment;
	}
	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}
	public Set<Cart> getCart() {
		return cart;
	}
	public void setCart(Set<Cart> cart) {
		this.cart = cart;
	}
	
	public Set<Product> getProduct() {
		return product;
	}
	public void setProduct(Set<Product> product) {
		this.product = product;
	}
	public String getDeliveryTime() {
		return deliveryTime;
	}
	public void setDeliveryTime(String deliveryTime) {
		this.deliveryTime = deliveryTime;
	}

	public void addProduct(Product product) {
		this.product.add(product);
	}
	public void removeProduct (Product product) {
		this.product.remove(product);
	}
	public Customer getCustomer() {
		return customer;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Orders() {
		
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public Integer getId() {
		return id;
	}
	public Priority getPrio() {
		return prio;
	}
	public void setPrio(Priority prio) {
		this.prio = prio;
	}
	public Supply getType() {
		return type;
	}
	public void setType(Supply type) {
		this.type = type;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public List<Kitchen> getKitchen() {
		return kitchen;
	}
	public void setKitchen(List<Kitchen> kitchen) {
		this.kitchen = kitchen;
	}
	@Override
	public String toString() {
		return "Orders [id=" + id + ", description=" + description + ", createDate=" + createDate + ", type=" + type
				+ ", prio=" + prio + ", cart=" + cart
				+ ", employee=" + employee + "]";
	}
	

}
