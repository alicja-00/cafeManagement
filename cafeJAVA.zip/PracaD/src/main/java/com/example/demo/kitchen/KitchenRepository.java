package com.example.demo.kitchen;

import org.springframework.data.jpa.repository.JpaRepository;



public interface KitchenRepository extends JpaRepository <Kitchen, Integer>{

}
