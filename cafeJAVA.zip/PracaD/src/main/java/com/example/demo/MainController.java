package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller // To oznacza, że klasa to Controller
public class MainController {
		
		@GetMapping("")
		public String viewHomePage() {
			return "index";
		}
		@GetMapping("menu")
		public String viewMenu() {
			return "menu";
		}
		@GetMapping("customer-management")
		public String viewCustomer() {
			return "customer_management";
		}
		@GetMapping("shopping-cart")
		public String viewShopCart() {
			return "shop_cart";
		}
		@GetMapping("employee-management")
		public String viewEmployee() {
			return "employee_management";
		}
		@GetMapping("orders-management")
		public String viewOrders() {
			return "orders_management";
		}
		@GetMapping("reports")
		public String viewReports() {
			return "reports";
		}
}
