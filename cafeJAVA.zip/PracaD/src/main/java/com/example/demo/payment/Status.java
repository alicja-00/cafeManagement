package com.example.demo.payment;

public enum Status {
	realized ("realized"),
	inProgres ("in progress"),
	rejected ("rejected");
	
	private final String name;

	public String getName() {
		return name;
	}

	private Status(String name) {
		this.name = name;
	}
}
